package shopJava;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Customer {
	private String name;
	private double budget;
	private ArrayList<Productstock> shoppingList;

	public Customer(String filename) {
		shoppingList = new ArrayList<>();
		List<String> lines = Collections.emptyList();
		try {
			lines = Files.readAllLines(Paths.get(filename), StandardCharsets.UTF_8);
			String[] firstLine = lines.get(0).split(",");
			name = firstLine[0];
			budget = Double.parseDouble(firstLine[1]);
			// i am removing at index 0 as it is the only one treated differently
			lines.remove(0);
			for (String line : lines) {
				String[] arr = line.split(",");
				String name = arr[0];
				int quantity = Integer.parseInt(arr[1].trim());
				Product p = new Product(name, 0);
				Productstock s = new Productstock(p, quantity);
				shoppingList.add(s);
			}
		}

		catch (IOException e) {

			// do something
			e.printStackTrace();
		}

	}

	public String getName() {
		return name;
	}

	public double getBudget() {
		return budget;
	}

	public ArrayList<Productstock> getShoppingList() {
		return shoppingList;
	}

	@Override
	public String toString() {
		// String ret = "Customer [name=" + name + ", budget=" + budget + "]\n";
		String 	ret = "*---CUSTOMER Name and Budget---*\n";
				ret+= "CUSTOMER NAME: "+ name +"\n";
				ret+= "CUSTOMER BUDGET: "+ budget +"\n";
				ret+= "*------------------------------*\n";
				
		ret+= "*---CUSTOMER shoppingList ---*\n"; 
		for (Productstock productstock : shoppingList) {
			//ret+= productstock.getProduct().getName() + " Quantity: " + productstock.getQuantity() + "\n";
			ret+= "PRODUCT NAME: "+ productstock.getProduct().getName()+"\n";
			ret+= "PRODUCT QUANTITY: "+ productstock.getQuantity()+"\n";
			ret+= "***\n";
		}
		ret+= "*------------------------------*\n"; 
		return ret;
	}


}
