package shopJava;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.io.*;

public class Shop {
	private double cash;
	private ArrayList<Productstock> stock;

	public Shop(String filename) {
		stock = new ArrayList<>();
		List<String> lines = Collections.emptyList();
		try {
			lines = Files.readAllLines(Paths.get(filename), StandardCharsets.UTF_8);
			lines = Files.readAllLines(Paths.get(filename), StandardCharsets.UTF_8);
			// System.out.println(lines.get(0));
			cash = Double.parseDouble(lines.get(0));
			lines.remove(0);
			for (String line : lines) {
				String[] arr = line.split(",");
				String name = arr[0];
				double price = Double.parseDouble(arr[1]);
				int quantity = Integer.parseInt(arr[2].trim());
				Product p = new Product(name, price);
				Productstock s = new Productstock(p, quantity);
				// System.out.println(s);
				// System.out.println(p);
				stock.add(s);
			}

		}

		catch (IOException e) {

			// do something
			e.printStackTrace();
		}
	}

	public double getCash() {
		return cash;
	}

	public ArrayList<Productstock> getStock() {
		return stock;
	}

	public void setStock(ArrayList<Productstock> stock) {
		this.stock = stock;
	}

	@Override
	public String toString() {
		// String ret = "Shop [cash=" + cash + ", stock=" + stock + "]";
		String ret = "*--- :: START ::  Initial Cash Position---*\n";
		ret += "The initial cash position of the Shop is  " + cash + "\n";
		ret += "*-----------------------------------------*\n";
		ret += "*-Stock position of the Shop----*\n";
		for (Productstock productstock : stock) {
			ret += "PRODUCT NAME: " + productstock.getProduct().getName() + "\n";
			ret += "PRODUCT PRICE: " + productstock.getProduct().getPrice() + "\n";
			ret += "Stock Quantity: The shop has " + productstock.getQuantity() + " of the above\n";
			ret += "***\n";
		}
		ret += "-----------------------------------";
		return ret;

	}

	public static void Smenu() {
		System.out.println("*The SHOP Program*");
		System.out.println("-MENU-");
		System.out.println("Type 'A' for Shop Stock position");
		System.out.println("Type 'B' for Customer Shopping List");
		System.out.println("Type 'C' for Customer Shopping list fulfillment");
		System.out.println("Type 'D' for On-line Input");
		System.out.println("Type 'X' to exit the application\n");
		System.out.println("Enter the menu option");
	}

	public static void main(String[] args) {

		Smenu();

		// System.out.println("Input" + menu);

		Scanner scan = new Scanner(System.in);
		char menu = scan.next().charAt(0);
		String status;

		if (menu == 'A') {
			Shop shop = new Shop("src/shopJava/stock.csv");
			System.out.println(shop);
			main(args);

		} else if (menu == 'B') {
			Customer somu = new Customer("src/shopJava/customer.csv");
			System.out.println(somu);
			main(args);
		} else if (menu == 'C') {
			Shop shop = new Shop("src/shopJava/stock.csv");
			Customer somu = new Customer("src/shopJava/customer.csv");
			double cbalance = 0.0;

			for (int counter = 0; counter < somu.getShoppingList().size(); counter++) {
				for (int counteri = 0; counteri < shop.getStock().size(); counteri++) {

					String Sname = somu.getShoppingList().get(counter).getProduct().getName();
					int Sint = somu.getShoppingList().get(counter).getQuantity();
					double Sbudget = somu.getBudget();
					String Stname = shop.getStock().get(counteri).getProduct().getName();
					double Sdouble = shop.getStock().get(counteri).getProduct().getPrice();
					int Squantity = shop.getStock().get(counteri).getQuantity();
					double Scash = shop.getCash();

					if (Sname.compareTo(Stname) == 0) {
						double Scost = Sint * Sdouble;
						if ((Squantity <= Sint) && ((cbalance + Scost) <= Sbudget)) {
							cbalance = cbalance + Scost;
							status = "Success";
							Scash = Scash + Scost;
							Product p = shop.getStock().get(counteri).getProduct();
							Productstock s = new Productstock(p, (Squantity - Sint));
							shop.stock.set(counteri, s);
						} else if (Sint > Squantity) {
							status = "Insufficient Stock";
						} else if (cbalance < Scost) {
							status = "Insufficient Cash";
						}

					}

				}
			}
			
			System.out.println(shop);

		} else if (menu == 'D') {

		} else if (menu == 'X') {
			System.out.println("Existing the applicaiton");
			System.exit(0);

		}
		scan.close();
	}

	private ArrayList<Productstock> setstock() {
		// TODO Auto-generated method stub
		return null;
	}

}
