#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

// Define the product Structure
struct Product {
	char* name;
	double price;
};

//Define the Product Stock Structure
struct ProductStock {
	struct Product product;
	int quantity;
};

//Define the Shop Structure
struct Shop {
	double cash;
	struct ProductStock stock[20];
	int index;
};

//Define the Customer Structure
struct Customer {
	char* name;
	double budget;
	struct ProductStock shoppingList[10];
	int index;
};

// function to print the product name and price from structure product
void printProduct(struct Product p)
{
	printf("PRODUCT NAME: %s \nPRODUCT PRICE: %.2f\n", p.name, p.price);
	
}

// function to print the product name from structure product
void printProductname(struct Product p)
{
	printf("PRODUCT NAME: %s \n", p.name);
	
}

// function to print the custmer name and Budget
// Also prints the name of the required product and the required quantity
void printCustomer(struct Customer c)
{
    printf("\n");
	printf("*---CUSTOMER Name and Budget---*\n");
	printf("CUSTOMER NAME: %s \nCUSTOMER BUDGET: %.2f\n", c.name, c.budget);
	printf("*------------------------------*\n");
	
	printf("\n");
	printf("*---CUSTOMER shoppingList ---*\n");
	for(int i = 0; i < c.index; i++)
	{
		printProductname(c.shoppingList[i].product);
		printf("PRODUCT QUANTITY: %d \n",  c.shoppingList[i].quantity);
	//	double cost = c.shoppingList[i].quantity * c.shoppingList[i].product.price; 
	//	printf("The cost to %s will be €%.2f\n", c.name, cost);
		printf("***\n");
	}
	printf("\n");
	printf("*-----------------------------*\n");
}

// this particular function is used by the multiple options in the shop Menu to validate and resturn the results
// Option C -- To process the Customer shopping list supplied through CSV
// Option D -- To process the online product request by the customer. Details entered through Console
// This functions accepts 3 parameters ( Shop Structure, Customer Structure and Print options)

void validate(struct Shop s,struct Customer c, int option)
{
    if (option == 2) {
    printf("********\n");
    printf("CUSTOMER NAME: %s \nCUSTOMER BUDGET: %.2f\n", c.name, c.budget);
    printf("The initial cash position of the Shop is %.2f \n", s.cash);
    printf("********\n");
    }
    double sbalance = 0.00;
    double cbalance = 0.00;
    char* status;
    
    	for(int i = 0; i < c.index; i++)
	{
	    for(int j=0; j<s.index; j++)
	    {
		   if (strcmp(c.shoppingList[i].product.name, s.stock[j].product.name) == 0)
		    {
		       
		       double scost = c.shoppingList[i].quantity * s.stock[j].product.price;
		       
		       if ((c.shoppingList[i].quantity <= s.stock[j].quantity) && ((cbalance+scost) <= c.budget))
		       {
		        cbalance = cbalance+scost;
		        status = "Success";
		        s.cash = s.cash + scost;
		        c.budget = c.budget - scost;
		        s.stock[j].quantity = s.stock[j].quantity - c.shoppingList[i].quantity;
		       }
		       else if (c.shoppingList[i].quantity > s.stock[j].quantity)
		       {
		          status = "Insufficient Stock"; 
		       }
		       else if ((cbalance+scost) > c.budget)
			   {
		          status = "Insufficient Cash"; 
		       }
		       
		       
            if (option == 1) {
                 printf("-----------------------------------------------------------\n");
              }
		       
		       printf("%s|Required Quantity: %d|Stock Quantity: %d|Unit cost: €%.2f|\n\
		       Total cost: €%.2f |CUSTOMER balance: €%.2f |Shop position: €%.2f |%s\n",
		        c.shoppingList[i].product.name, \
		        c.shoppingList[i].quantity,\
		        s.stock[j].quantity,\
		        s.stock[j].product.price,\
		        scost,\
		        c.budget, \
		        s.cash,\
		        status);
		        
		   if (option == 1) {
                 printf("-----------------------------------------------------------\n");
              }
 
		    }
	    }
	}
	printf("********\n");
}

// Author: Somu 
// Date: 23rd October
// Adoped from lessons and Modified to read the initial cash value of the Shop
struct Shop createAndStockShop()
{
	
    FILE * fp;
    char * line = NULL;
    size_t len = 0;
    ssize_t read;
    int lines=0;
    struct Shop shop = {} ;

    fp = fopen("stock.txt", "r");
    if (fp == NULL)
        exit(EXIT_FAILURE);

    while ((read = getline(&line, &len, fp)) != -1) {
        

        if (lines == 0)
        {
            char *n = strtok(line, ",");
		    char *p = strtok(NULL, ",");  
		    double Icashposition = atof(p);
            shop.cash = Icashposition;
        }
        else
        {
		    char *n = strtok(line, ",");
		    char *p = strtok(NULL, ",");
		    char *q = strtok(NULL, ",");
		    int quantity = atoi(q);
		    double price = atof(p);
		    char *name = malloc(sizeof(char) * 50);
		    strcpy(name, n);
		    struct Product product = { name, price };
		    struct ProductStock stockItem = { product, quantity };
		    shop.stock[shop.index++] = stockItem;
        }
        lines++;
    }
	fclose(fp);
	return shop;
}

// Author: Somu 
// Date: 23rd October
// Read from the customer CSV files
struct Customer createAndCustomer()
{
	
    FILE * fp;
    char * line = NULL;
    size_t len = 0;
    ssize_t read;
    int lines=0;
    struct Customer customer = {} ;

    fp = fopen("customer.txt", "r");
    if (fp == NULL)
        exit(EXIT_FAILURE);

    while ((read = getline(&line, &len, fp)) != -1) {
        

        if (lines == 0)
        {
            char *n = strtok(line, ",");
		    char *p = strtok(NULL, ",");  
		    double Icashposition = atof(p);
            customer.budget = Icashposition;
            char *name = malloc(sizeof(char) * 50);
		    strcpy(name, n);
		    customer.name = name;
        }
        else
        {
		    char *n = strtok(line, ",");
		   // char *p = strtok(NULL, ",");
		    char *q = strtok(NULL, ",");
		    int quantity = atoi(q);
		    double price = 0.00;
		    char *name = malloc(sizeof(char) * 50);
		    strcpy(name, n);
		    struct Product product = { name, price };
		    struct ProductStock stockItem = { product, quantity };
		    customer.shoppingList[customer.index++] = stockItem;
        }
        lines++;
    }
	fclose(fp);
	return customer;
}

// Option D - To read the value from the Customer CSV files
struct Customer onlineCustomer(char * name, int quantity, double budget)
{
    struct Customer customer = {} ;
    double price = 0.00;
    struct Product product = { name, price };
    struct ProductStock stockItem = { product, quantity };
    customer.budget = budget;
    customer.shoppingList[customer.index++] = stockItem;
	return customer;
}

// Print the cash and stock postion of the shop
void printShop(struct Shop s)
{
    printf("*---Initial Cash Position---*\n");
	printf("The initial cash position of the Shop is %.2f \n", s.cash);
	printf("*---------------------------*\n");
	
	printf("\n");
	printf("*-Stock position of the Shop----*\n");
	for (int i = 0; i < s.index; i++)
	{
		printProduct(s.stock[i].product);
		printf("Stock Quantity: The shop has %d of the above\n", s.stock[i].quantity);
		printf("***\n");
	}
	printf("*-------------------------------*\n");
}

// re-usable menu functions
void menu()
{
    printf("*The SHOP Program*\n");
    printf("-Menu-\n");
    printf(" Type 'A' for Shop Stock Position.\n");
    printf(" Type 'B' for Customer shopping list.\n");
    printf(" Type 'C' for Customer shopping list fulfilment.\n");
    printf(" Type 'D' On-line Input.\n");
    printf(" Type 'X' to exit the application.\n\n");
    printf("Enter the Menu Option >\n");
    }


// Flushes any unwanted characters while supplying the input
void flush()
{
    int c;
    while ((c = getchar()) != '\n' && c != EOF) ;
}

// Removing leading and trailing white spaces
char *removeSpaces(const char *string) {

    while(isspace((unsigned char)string[0]))
        string++;
    char *final = strdup(string);
    int length = strlen(final);
    while(length > 0 && isspace((unsigned char)final[length-1]))
        length--;
    final[length] = '\0';
    return final;
}


// The main function 
// Option A - Provdies the shop position - Cash and the quanity of the stock available
// Option B - What is required by the Customer and the customers cash position
// Option C - Customer shopping list fulfillment
// Option D - Online handling of the customer request (One Product only at a time)

int main(void) 
{
    char chr;
    
    menu();
    

        
        
    while(1) {
        scanf("%c",&chr);
        
        if (chr == 'A')
        {
	        struct Shop shop = createAndStockShop();
	        printShop(shop);
        }
        else if (chr == 'B')
        {
	        struct Customer customer = createAndCustomer();
	        printCustomer(customer);
        }
        else if (chr == 'C')
        {
	        struct Shop shop = createAndStockShop();
	        struct Customer customer = createAndCustomer();
	        validate (shop, customer, 2);
        }
        else if (chr == 'D')
        {

            char pname[50];
            int count = 0;
            int quantity;
            int number;
            double budget=100.00;
            double cbudget = 0.00;
            


           // strcpy(name,Rname());
            flush();
            printf("Enter a  required product:  \n");
            fgets(pname, 50, stdin);

            char *name = malloc(sizeof(char) * 50);
            strcpy(name, removeSpaces(pname));

            printf("\n");
            printf("Enter Quantity:  ");
            scanf("%d", &number);
            printf("\n");
            printf("Enter Customer payment amount: ");
            scanf("%lf", &cbudget);
            printf("\n");
            
           struct Shop shop = createAndStockShop();
           struct Customer customer = onlineCustomer(name,number,cbudget);
           validate (shop, customer, 1);
           
        }
        else if (chr == 'X')
        {
        printf("Exiting the Application");
	    exit(0);
        }
        else
        { 
         menu();
        }
    }
    return 0;

}
