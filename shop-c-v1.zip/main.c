#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct Product {
	char* name;
	double price;
};

struct ProductStock {
	struct Product product;
	int quantity;
};

struct Shop {
	double cash;
	struct ProductStock stock[20];
	int index;
};

struct Customer {
	char* name;
	double budget;
	struct ProductStock shoppingList[10];
	int index;
};


void printProduct(struct Product p)
{
	printf("PRODUCT NAME: %s \nPRODUCT PRICE: %.2f\n", p.name, p.price);
	
}

void printCustomer(struct Customer c)
{
    printf("\n");
	printf("*--- :: START ::  CUSTOMER Name and Budget -------------------------*\n");
	printf("CUSTOMER NAME: %s \nCUSTOMER BUDGET: %.2f\n", c.name, c.budget);
	printf("*--- :: END ::    CUSTOMER Name and Budget -------------------------*\n");
	
	printf("\n");
	printf("*--- :: START ::  CUSTOMER shoppingList -------------------------*\n");
	for(int i = 0; i < c.index; i++)
	{
		printProduct(c.shoppingList[i].product);
		printf("%s ORDERS %d OF ABOVE PRODUCT\n", c.name, c.shoppingList[i].quantity);
		double cost = c.shoppingList[i].quantity * c.shoppingList[i].product.price; 
		printf("The cost to %s will be €%.2f\n", c.name, cost);
		printf("********\n");
	}
	printf("\n");
	printf("*--- :: END ::  CUSTOMER shoppingList -------------------------*\n");
}


void validate(struct Shop s,struct Customer c)
{
    printf("********\n");
    printf("CUSTOMER NAME: %s \nCUSTOMER BUDGET: %.2f\n", c.name, c.budget);
    printf("The initial cash position of the Shop is %.2f \n", s.cash);
    printf("********\n");
    double sbalance = 0.00;
    double cbalance = 0.00;
    char* status;
    
    	for(int i = 0; i < c.index; i++)
	{
	    for(int j=0; j<s.index; j++)
	    {
		   if (strcmp(c.shoppingList[i].product.name, s.stock[j].product.name) == 0)
		    {
		       
		       double scost = c.shoppingList[i].quantity * s.stock[j].product.price;
		       
		       if ((c.shoppingList[i].quantity <= s.stock[j].quantity) && ((cbalance+scost) <= c.budget))
		       {
		        cbalance = cbalance+scost;
		        status = "Success";
		        s.cash = s.cash + scost;
		        c.budget = c.budget - scost;
		        s.stock[j].quantity = s.stock[j].quantity - c.shoppingList[i].quantity;
		       }
		       else if (c.shoppingList[i].quantity > s.stock[j].quantity)
		       {
		          status = "Insufficient Stock"; 
		       }
		       else if ((cbalance+scost) > c.budget)
			   {
		          status = "Insufficient Cash"; 
		       }	       

		       
		       printf("%s|Required Quantity: %d|Stock Quantity: %d|Unit cost: €%.2f|\n\
		       Total cost: €%.2f |CUSTOMER balance: €%.2f |Shop position: €%.2f |%s\n",
		        c.shoppingList[i].product.name, \
		        c.shoppingList[i].quantity,\
		        s.stock[j].quantity,\
		        s.stock[j].product.price,\
		        scost,\
		        c.budget, \
		        s.cash,\
		        status);
 
		    }
	    }
	}
	printf("********\n");
}

// Author: Somu 
// Date: 23rd October
// Modified to read the initial cash value of the Shop
struct Shop createAndStockShop()
{
	
    FILE * fp;
    char * line = NULL;
    size_t len = 0;
    ssize_t read;
    int lines=0;
    struct Shop shop = {} ;

    fp = fopen("stock.txt", "r");
    if (fp == NULL)
        exit(EXIT_FAILURE);

    while ((read = getline(&line, &len, fp)) != -1) {
        

        if (lines == 0)
        {
            char *n = strtok(line, ",");
		    char *p = strtok(NULL, ",");  
		    double Icashposition = atof(p);
            shop.cash = Icashposition;
        }
        else
        {
		    char *n = strtok(line, ",");
		    char *p = strtok(NULL, ",");
		    char *q = strtok(NULL, ",");
		    int quantity = atoi(q);
		    double price = atof(p);
		    char *name = malloc(sizeof(char) * 50);
		    strcpy(name, n);
		    struct Product product = { name, price };
		    struct ProductStock stockItem = { product, quantity };
		    shop.stock[shop.index++] = stockItem;
        }
        lines++;
    }
	fclose(fp);
	return shop;
}

// Author: Somu 
// Date: 23rd October
// Read from the customer CSV files
struct Customer createAndCustomer()
{
	
    FILE * fp;
    char * line = NULL;
    size_t len = 0;
    ssize_t read;
    int lines=0;
    struct Customer customer = {} ;

    fp = fopen("customer.txt", "r");
    if (fp == NULL)
        exit(EXIT_FAILURE);

    while ((read = getline(&line, &len, fp)) != -1) {
        

        if (lines == 0)
        {
            char *n = strtok(line, ",");
		    char *p = strtok(NULL, ",");  
		    double Icashposition = atof(p);
            customer.budget = Icashposition;
            char *name = malloc(sizeof(char) * 50);
		    strcpy(name, n);
		    customer.name = name;
        }
        else
        {
		    char *n = strtok(line, ",");
		   // char *p = strtok(NULL, ",");
		    char *q = strtok(NULL, ",");
		    int quantity = atoi(q);
		    double price = 0.00;
		    char *name = malloc(sizeof(char) * 50);
		    strcpy(name, n);
		    struct Product product = { name, price };
		    struct ProductStock stockItem = { product, quantity };
		    customer.shoppingList[customer.index++] = stockItem;
        }
        lines++;
    }
	fclose(fp);
	return customer;
}

struct Customer onlineCustomer(char *name, int quantity)
{
	
    struct Customer customer = {} ;
    double price = 0.00;
    struct Product product = { name, price };
    struct ProductStock stockItem = { product, quantity };
    customer.shoppingList[customer.index++] = stockItem;
	return customer;
}

void printShop(struct Shop s)
{
    printf("*--- :: START ::  Shop CSV file modified to read & display initial CASH position---*\n");
	printf("The initial cash position of the Shop is %.2f \n", s.cash);
	printf("*--- :: END   ::  Shop CSV file modified to read & display initial CASH position---*\n");
	
	printf("\n");
	printf("*--- :: START ::  Stock position of the Shop-------------------------*\n");
	for (int i = 0; i < s.index; i++)
	{
		printProduct(s.stock[i].product);
		printf("Stock Quantity: The shop has %d of the above\n", s.stock[i].quantity);
		printf("********\n");
	}
	printf("*--- :: End ::   Stock position of the Shop-------------------------*\n");
}

void menu()
{
    printf("******************The SHOP Program*****************\n");
    printf("------------------------Menu-----------------------\n");
    printf(" Type 'A' for Shop Stock Position.\n");
    printf(" Type 'B' for Customer shopping list.\n");
    printf(" Type 'C' for Customer shopping list fulfilment.\n");
    printf(" Type 'D' On-line Input.\n");
    printf(" Type 'X' to exit the application.\n");
    printf("---------------------------------------------------\n");
    }


int main(void) 
{
    char chr;
    
    menu();
    
        while (1)
    {
        scanf("%c",&chr);
    
        if (chr == 'A')
        {
	        struct Shop shop = createAndStockShop();
	        printShop(shop);
	        menu();
        }
        else if (chr == 'B')
        {
	        struct Customer customer = createAndCustomer();
	        printCustomer(customer);
	        menu();
        }
        else if (chr == 'C')
        {
	        struct Shop shop = createAndStockShop();
	        struct Customer customer = createAndCustomer();
	        validate (shop, customer);
	        menu();
        }
        else if (chr == 'D')
        {
	        struct Shop shop = createAndStockShop();
	            
            char name[20];
            printf("Enter the Product name\n");
            scanf("%s", name);
    
            int quantity ;
            while(1) {

                    char line[MAXLINE];
                    int n = 0;
                    while (fgets(line, MAXLINE, stdin))
                    {
                        while (sscanf(line, "%d", &n) == 1)
                            {
                                printf("%d ", n);
                            }
                    }
            }
	        struct Customer customer = onlineCustomer(name,quantity);
	        validate (shop, customer);
	              }
        else if (chr == 'X')
        {
	    break;
        }
    }
    return 0;

}
